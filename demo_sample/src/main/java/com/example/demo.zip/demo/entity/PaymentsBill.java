package com.example.demo.entity;
import lombok.*;
import javax.persistence.Entity;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.*;


@Entity
@Data
@Table(name = "paymentsBill")
public class PaymentsBill{
	@Id
    @GeneratedValue
	private @NonNull Long pay_id;
    private @NonNull String userName;
	//private @NonNull String name_import;
	//private @NonNull String name_export;



@OneToMany(mappedBy="paymentsBill",cascade = CascadeType.ALL) 
private List<WarehouseImport> warhouseImport = new ArrayList<>();

@OneToMany(mappedBy="paymentsBill",cascade = CascadeType.ALL) 
private List<WarehouseExport> warhouseExport = new ArrayList<>();
	

	protected PaymentsBill(){}

	public PaymentsBill(String userName){
		this.userName = userName;
	//	this.name_import = name_import;
	//	this.name_export = name_export;
		
	}

	
}



