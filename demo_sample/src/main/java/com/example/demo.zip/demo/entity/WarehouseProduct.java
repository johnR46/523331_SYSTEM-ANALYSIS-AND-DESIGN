package com.example.demo.entity;
import lombok.*;
import javax.persistence.Entity;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.*;


@Entity
@Data
public class WarehouseProduct{
    @Id
    @GeneratedValue
	private @NonNull Long product_id;
    private @NonNull String name_product;
  //  private @NonNull String price;
   // private @NonNull Date date;
    //private @NonNull String Qty;

   

@OneToMany(mappedBy="WarehouseProduct",cascade = CascadeType.ALL) 
private List<WarehouseImport> warhouseImport = new ArrayList<>();


@OneToMany(mappedBy="WarehouseProduct",cascade = CascadeType.ALL) 
private List<WarehouseExport> warhouseExport = new ArrayList<>();



    
    protected WarehouseProduct(){}

public WarehouseProduct(String name_product){
        this.name_product = name_product;
       // this.price = price;
       // this.date = date;
       // this.Qty = Qty;

	}


}


