package com.example.demo.entity;
import lombok.*;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;

@Entity
@Data
@Table(name = "WarehouseImport")
public class WarehouseImport{
    @Id
    @GeneratedValue
	private @NonNull Long import_id;
    private @NonNull String name_import;
   // private @NonNull String price;
    //private @NonNull Date date;


//manytoone  with PaymentsBill
@ManyToOne(fetch = FetchType.LAZY)   
@JoinColumn(name= "pay_id")      
private PaymentsBill paymentsBill;


//manytoone  with warehouseproduct
@ManyToOne(fetch = FetchType.LAZY)   
@JoinColumn(name = "product_id")      
private WarehouseProduct warehouseProduct;


    protected WarehouseImport(){}

public WarehouseImport(String name_import){
        this.name_import = name_import;
    //    this.price = price;
      //  this.date  = date;
	}






}


