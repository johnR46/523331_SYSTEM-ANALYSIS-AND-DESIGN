package com.example.demo.entity;
import lombok.*;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;

@Entity
@Data
@Table(name = "WarehouseExport")
public class WarehouseExport{
    @Id
    @GeneratedValue
	private @NonNull Long export_id;
    private @NonNull String name_export;
   // private @NonNull String price;
   // private @NonNull Date date;

    

//manytoone  with PaymentsBill
@ManyToOne(fetch = FetchType.LAZY)   
@JoinColumn(name = "pay_id")      
private PaymentsBill paymentsBill;


   
//manytoone  with warehouseproduct
@ManyToOne(fetch = FetchType.LAZY)   
@JoinColumn(name = "product_id")      
private WarehouseProduct warehouseProduct;
   
   
    
protected WarehouseExport(){}

public WarehouseExport(String name_export){
        this.name_export = name_export;
     //   this.price = price;
       // this.date = date;
           
	}





}


