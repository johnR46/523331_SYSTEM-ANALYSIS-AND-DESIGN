import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-type-product-warehouse',
  templateUrl: './type-product-warehouse.component.html',
  styleUrls: ['./type-product-warehouse.component.css']
})
export class TypeProductWarehouseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
